<?php
$host="localhost";
$user="rodrigo";
$password="rodrigo";
$db="registro";
$con = new mysqli($host,$user,$password,$db);

$username=$_POST['usuario'];
$password=$_POST['password'];
 
 
$sql = "SELECT Usuario, Password FROM administrador WHERE Usuario = '" . $username . "' and Password='".$password."';";
$query=mysqli_query($con,$sql);
$counter=mysqli_num_rows($query);

if ($counter==1){
		echo "<script>alert(\"Usted a ingresado correctamente\");
        window.location='DatosdelAlumno.php';
        </script>";
}else{
    echo '<script>
        alert("Usuario o Contraseña incorrecta");
        window.history.go(-1)
        </script>
    ';
    exit;
} 

?>
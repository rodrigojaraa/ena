<html>
    <head>
        <title>Iniciar Sesion</title>
        <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">         
    </head>
    <style type="text/css">
    
    body {
    background-image: url(Fondodepantallacolegios.jpg);
    text-align:inherit;
}
#contenedor {
    position:relative;
    border: 5px solid #87ceeb;
    height:320px;
    width:450px;
    margin:90px auto;    
    background-color:#cdcdcd;
}
#titulo, #labelusuario, #textousuario, #labelpassword, #textopassword, #btningresar, #btnsalir {
     position:absolute;
}
#titulo {    
    height:20px;
    width:450px;
    text-align:inherit;
    font-weight:bold;
    color:#000000;
    background-color:#87ceeb;
}
 #labelusuario, #labelpassword {
    
    width:500px;   
}
 #textousuario, #textopassword {
    width:130px;
    border:1px solid black;
}
#labelusuario {
    top:90px;
    left:100px;
}
#textousuario {
    top:90px;
    left:220px;
}
#labelpassword {
    top:150px;
    left:100px;
}
#textopassword {
    top:150px;
    left:220px;
}
#btningresar {
    width:100px;
    top:240px;
    Right:250px;
    height:30px;
    cursor:pointer;
}        
#btnsalir{
    width:100px;
    top:240px;
    Right:100px;
    height:30px;
    cursor:pointer;
}
    </style>
    <body>
        <div id="contenedor">
            <div id="titulo">Login</div>
             <form id="form1" action="RegistroDeSesion.php" method="post">
                 
                 <label id="labelusuario"  >Usuario:</label>
                 <input id="textousuario" name="usuario" type="text"/> 
 
                 <label id="labelpassword" >Password:</label>
                 <input id="textopassword" name="password" type="password"/> 
                 
                 <input type="submit" id="btningresar" name="btningresar" value="Ingresar"/>
                 
                 <input type="reset" id="btnsalir" name="btnsalir" value="Salir"/>
                                                         
             </form>
        </div>
    </body>
</html>
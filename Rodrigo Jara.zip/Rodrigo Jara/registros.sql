Create database registro;
Use registro;

CREATE TABLE alumnos (
  CedulaRut varchar(12) NOT NULL PRIMARY KEY,
  Nombres varchar(50) NOT NULL,
  Apellidos varchar(50) NOT NULL,
  Edad NUMERIC(3) NOT NULL,
  Fecha_De_Nacimiento varchar(50) NOT NULL,
  Pais varchar(50) NOT NULL,
  Ciudad varchar(50) NOT NULL,
  Provincia varchar(50) NOT NULL,
  Telefono NUMERIC(9) NOT NULL,
  Direccion varchar(50) NOT NULL,
  Sexo varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE docente (
  Nombres varchar(50) NOT NULL,
  Apellidos varchar(50) NOT NULL,
  Cedula varchar(12) NOT NULL PRIMARY KEY,
  Edad NUMERIC(3) NOT NULL,
  Fecha_De_Nacimiento varchar(50) NOT NULL,
  Pais varchar(50) NOT NULL,
  Ciudad varchar(50) NOT NULL,
  Provincia varchar(50) NOT NULL,
  Telefono NUMERIC(9) NOT NULL,
  Direccion varchar(50) NOT NULL,
  Sexo varchar(50) NOT NULL,
  Profesion varchar(50) NOT NULL,
  Posgrado varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE administrador (
  Rut varchar(12) NOT NULL PRIMARY KEY, 
  Nombre varchar(50) NOT NULL,
  Apellidos varchar(50) NOT NULL,
  Usuario varchar(50) NOT NULL UNIQUE,
  Password varchar(50) NOT NULL UNIQUE,
  Cedula varchar(12),
  FOREIGN KEY (Cedula) REFERENCES docente (Cedula)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE modulo (
  Codigo_del_Modulo varchar(30) NOT NULL PRIMARY KEY,
  Nombre varchar(50) NOT NULL,
  Carrera varchar(50) NOT NULL,
  Semestre NUMERIC(2) NOT NULL,
  Sede varchar(50) NOT NULL,
  Inicio varchar(50) NOT NULL,
  Termino varchar(50) NOT NULL,
  Sala NUMERIC(3) NOT NULL,
  Bloque varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE notas (
  Cod_nota varchar(3) NOT NULL PRIMARY KEY,
  Rut_del_Alumno varchar(12) NOT NULL,
  Evaluacion1 NUMERIC(4) NOT NULL,
  Evaluacion2 NUMERIC(4) NOT NULL,
  Evaluacion3 NUMERIC(4) NOT NULL,
  Modulo varchar(50) NOT NULL,
  Profesor varchar(50) NOT NULL,
  Nota_Examen NUMERIC(4) NOT NULL,
  Examen1 NUMERIC(4) NOT NULL,
  Examen2 NUMERIC(4) NOT NULL,
  Nota_Final NUMERIC(4) NOT NULL,
  Estado varchar(50) NOT NULL,
  CedulaRut varchar(12),
  Codigo_del_Modulo varchar(30),
  Cedula varchar(12),
  FOREIGN KEY (CedulaRut) REFERENCES alumnos (CedulaRut),
  FOREIGN KEY (Codigo_del_Modulo) REFERENCES modulo (Codigo_del_Modulo),
  FOREIGN KEY (Cedula) REFERENCES docente (Cedula)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO administrador(Rut,Nombre,Apellidos,Usuario,Password) VALUES('18.107.505-8','rodrigo','jara','alberto','rodrigo');


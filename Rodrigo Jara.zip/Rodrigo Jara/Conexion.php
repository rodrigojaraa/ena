<?php
$host="localhost";
$user="rodrigo";
$password="rodrigo";
$db="registros";
$con = new mysqli($host,$user,$password,$db);

?>
<?php
$host="localhost";
$user="rodrigo";
$password="rodrigo";
$db="registro";
$con = new mysqli($host,$user,$password,$db);

$Cedula = $_POST["cedularut"];
$Nombre = Trim($_POST["nombres"]);
$Apellidos = $_POST["apellidos"];
$Fechana = $_POST["fechadenacimiento"];
$Edad = $_POST["edad"];
$Sexo = $_POST["sexo"];
$Direccion = $_POST["direccion"];
$telefono = $_POST["telefono"];
$Provincia = $_POST["provincia"];
$Ciudad = Trim($_POST["ciudad"]);
$Pais = $_POST["pais"];
    
$insertar = "INSERT INTO alumnos (CedulaRut,Nombres,Apellidos, Fecha_De_Nacimiento, Edad, Sexo, Direccion , Telefono, Provincia, Ciudad, Pais ) VALUES('$Cedula','$Nombre','$Apellidos','$Fechana', $Edad ,'$Sexo','$Direccion',$telefono,'$Provincia','$Ciudad','$Pais')";    
    
$Verificar_rut = mysqli_query($con, "SELECT * FROM alumnos WHERE CedulaRut = '$Cedula'");
if (mysqli_num_rows($Verificar_rut)>0){
    echo '<script>
        alert("El rut ya esta registrado");
        window.history.go(-1)
        </script>
    ';
    exit;
}

$Resultado= mysqli_query($con, $insertar);

    if(!$Resultado){
        echo '<script>
            alert(("Error al registrar");
            window.history.go(-1)
            </script>
            ';
    } else {
        echo '<script>
        alert("Usuario Registrado exitosamente");
        window.history.go(-1)
        </script>
        ';
    }

    mysqli_close($con);
    
?>

<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Datos Personales</title>
    <link rel="stylesheet" type="text/css" href="css/Alumno.css">
    </head>
  <script type="text/javascript">
        function Salida(){
        window.location.href="DatosdelAlumno";
        }
        
    </script> 

    <body>
    <center>
       <form ACTION="" method="POST">

           <div id ="titulo">Datos Personales</div>
        
           <label id="cedula">Cedula(Rut)</label>
           <input id="cedularut" name="cedularut" type="text" pattern="^(\d{2}\.\d{3}\.\d{3}-)([a-zA-Z]{1}$|\d{1}$)"placeholder="xx.xxx.xxx-x" required> 
           
           <input type="submit" id="btnconsultar" name="submit" value="Consulta">
           <input type="button" id="salir" value="Salir" onclick="window.location.href='../Alumno.php';">
            </form>
        </center>
<?php
    
            $nombredelservidor = "localhost";
            $nombredeusuario = "rodrigo";
            $clave = "rodrigo";
            $basededatos="registro";

            $conn = new mysqli ($nombredelservidor, $nombredeusuario, $clave, $basededatos);
             
             
if(isset($_POST['submit'])){
            if(!empty($_POST)){
		          if($_POST["cedularut"]!=""){ 
                     $Cedula = ($_POST["cedularut"]);
			         $sql1= "select * from alumnos where (CedulaRut=\"$Cedula\") ";
			         $query = $conn->query($sql1);
                     if($r=$query->fetch_array()){
                    echo  "<center>";
                    echo "Rut: " . $r["CedulaRut"];
                    echo "<br>";  
                    echo "Nombre: " . $r["Nombres"];
                    echo "<br>"; 
                    echo "Apellido: " . $r["Apellidos"];
                      echo "<br>"; 
                    echo "Fecha de Nacimiento: " . $r["Fecha_De_Nacimiento"];
                      echo "<br>"; 
                    echo "Edad: " . $r["Edad"];
                      echo "<br>"; 
                    echo "Sexo: " . $r["Sexo"];
                      echo "<br>"; 
                    echo "Direccion: " . $r["Direccion"];
                      echo "<br>"; 
                    echo "Telefono: " . $r["Telefono"];
                      echo "<br>"; 
                    echo "Provinicia: " . $r["Provincia"];
                      echo "<br>"; 
                    echo "Ciudad: " . $r["Ciudad"];
                      echo "<br>"; 
                    echo "Pais: " . $r["Pais"];
                     echo  "</center>" ;
                         
                        }else{
                       echo  "<center>";
                      echo "no existe el rut";
                      echo  "</center>" ; 
                  }
                      
			}
		}
	}
    ?>    
    </body>
</html>
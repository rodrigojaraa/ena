<?php
include 'Conexion.php';
$CedulaRut = $_POST["cedularut"];
$Nombre = $_POST["nombres"];
$Apellidos = $_POST["apellidos"];
$Edad = $_POST["edad"];
$FechaDeNacimiento = $_POST["fechadenacimiento"];
$Pais = $_POST["pais"];
$Ciudad = $_POST["ciudad"];
$Provincia = $_POST["provincia"];
$Telefono = $_POST["telefono"];
$Direccion = $_POST["direccion"];
$Sexo = $_POST["sexo"];

$insertar = "INSERT INTO alumnos (Cedula/Rut, Nombres, Apellidos, Edad, Fecha De Nacimiento, Pais, Ciudad, Provincia, Telefono, Direccion, Sexo) 
VALUES('$CedulaRut','$Nombre','$Apellidos',$Edad,'$FechaDeNacimiento','$Pais','$Ciudad','$Provincia',$Telefono,'$Direccion','$Sexo')";

if(isset($_POST['btningresar'])){
$Verificar_rut = mysqli_query($Conexion, "SELECT * FROM alumnos WHERE Cedula/Rut ='$CedulaRut'");
if (mysqli_num_rows($Verificar_rut)>0){
    echo '<script>
        alert("El Rut ya esta registrado");
        window.history.go(-1)
        </script>
        ';
    } else {
        echo '<script>
        alert("Usuario registrado con exito");
        window.history.go(-1)
        </script>
        ';
    }
    
    mysqli_close($Conexion);
}

if(isset($_POST['btnbuscar'])){ 
    
    $Resultado1= mysqli_query($Conexion,"SELECT * FROM alumnos");
    if(!$Resultado1){
        echo 'Error al Consultar';
    }else{ 
        echo $Resultado1('Nombres');
    }
    
    mysqli_close($Conexion);
}
?>
